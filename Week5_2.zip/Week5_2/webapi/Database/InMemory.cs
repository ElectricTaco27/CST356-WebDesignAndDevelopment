using System.Collections.Generic;

namespace Database
{
    public static class InMemory
    {
        public static List<Student> students = new List<Student> {
            new Student {
                Id = 1,
                Email = "SAO@Gmail.com",
            },
            new Student {
                Id = 2,
                Email = "DanMachi@Gmail.com"
            },
            new Student {
                Id = 3,
                Email = "Apex@Gmail.com"
            },
            new Student {
                Id = 4,
                Email = "Abec@Gmail.com"
            }
        };

        public static List<Person> persons = new List<Person> {
            new Person {
                Id = 1,
                FirstName = "Riggs",
                MiddleInitial = 'D',
                LastName = "Burnham"
            },
            new Person {
                Id = 2,
                FirstName = "Asuna",
                MiddleInitial = 'F',
                LastName = "Yuuki"
            },
            new Person {
                Id = 3,
                FirstName = "Kazuto",
                MiddleInitial = 'K',
                LastName = "Kirigaya"
            },
            new Person {
                Id = 4,
                FirstName = "Aiz",
                MiddleInitial = 'H',
                LastName = "Wallenstien"
            }
        };
    }
}
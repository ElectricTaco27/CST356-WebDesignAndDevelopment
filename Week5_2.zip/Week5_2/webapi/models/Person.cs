public class Person
{
    public int Id;
    public string FirstName;
    public char MiddleInitial;
    public string LastName;
}
public class Student
{
    public int Id;
    public string Email;
}
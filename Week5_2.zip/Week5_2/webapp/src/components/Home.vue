<template>
  <div>

    <head>
      <link href="sharedcssfile.css" rel="stylesheet" type="text/css">
    </head>


    <h1 class = "HistVG_H1">History of Video Games 1</h1>
    <p>The history of video games goes as far back as the early 1950s, when academic computer scientists began designing simple games and simulations as part of their research or just for fun. At M.I.T. in the 1960s, professors and students played games such as 3D tic-tac-toe and Moon Landing. These games were played on computer such as the IBM 1560, and moves were made by means of punch cards. Video gaming did not reach mainstream popularity until the 1970s and 1980s, when video arcade games and gaming consoles using joysticks, buttons, and other controllers, along with graphics on computer screens and home computer games were introduced to the general public. Since the 1980s, video gaming has become a popular form of entertainment and a part of modern popular culture in most parts of the world. One of the early games was Spacewar!, which was developed by computer scientists. Early arcade video games developed from 1972 to 1978. During the 1970s, the first generation of home consoles emerged, including the popular game Pong and various "clones". The 1970s was also the era of mainframe computer games. The golden age of arcade video games was from 1978 to 1982. Video arcades with large, graphics-decorated coin-operated machines were common at malls and popular, affordable home consoles such as the Atari 2600 and Intellivision enabled people to play games on their home TVs. During the 1980s, gaming computers, early online gaming and handheld LCD games emerged; this era was affected by the video game crash of 1983. From 1976 to 1992, the second generation of video consoles emerged</p>
    <h1 id="header2">History of Video Games 2</h1>
    <p>The third generation of consoles, which were 8-bit units, emerged from 1983 to 1995. The fourth generation of consoles, which were 16-bit models, emerged from 1987 to 1999. The 1990s saw the resurgence and decline of arcades, the transition to 3D video games, improved handheld games, and PC gaming. The fifth generation of consoles, which were 32 and 64-bit units, was from 1993 to 2006. During this era, mobile phone gaming emerged. During the 2000s, the sixth generation of consoles emerged (1998–2013). During this period, online gaming and mobile games became major aspects of gaming culture. The seventh generation of consoles was from 2005 to 2012. This era was marked by huge development budgets for some games, with some having cinematic graphics; the launch of the top-selling Wii console, in which the user could control the game actions with real-life movement of the controller; the rise of casual PC games marketed to non-gamers;[citation needed] and the emergence of cloud computing in video games.</p>
    <h1 id="header3">History of Video Games 3</h1>
    <p>In 2013, the eighth generation of consoles emerged, including Nintendo's Wii U and Nintendo 3DS, Microsoft's Xbox One, and Sony's PlayStation 4 and PlayStation Vita. PC gaming has been holding a large market share in Asia and Europe for decades and continues to grow due to digital distribution. Since the development and widespread consumer use of smartphones, mobile gaming has been a driving factor for games, as they can reach people formerly uninterested in gaming, and those unable to afford or support dedicated hardware, such as video game consoles.</p>

    <img src = "../assets/SAO.jpg" alt="Sword Art Online">
    <img src = "../assets/FunnySao.gif" alt="Funny Sword Art Online">
    <img src = "https://i.pinimg.com/originals/db/5d/c4/db5dc4aad8ea096f682cf6c256acc76e.png" alt="SAO Logo From Internet">
  </div>
</template>

<script>
export default {
  name: 'Home',
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
  h1.HistVG_H1{
    color: purple;
    font-size: 28px;
    font-weight: bold;
  }

  #header2{
      color: green;
      font-size: 24px;
      font-weight: bolder;
  }

  #header3{
      color: pink;
      font-style: italic;
      font-size: 26px;
      font-family: 'Courier New';
  }
</style>
